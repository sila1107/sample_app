# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd33acb0045ec2b2da6300aef223c2a480c4d86f0fc3b1105eff740c3f16789fe24aa091adf76d381c78771801aca4372ff15009c707b058426cfa814d6622e99'